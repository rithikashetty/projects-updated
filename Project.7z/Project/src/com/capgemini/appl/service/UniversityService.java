package com.capgemini.appl.service;

import java.sql.Date;
import java.util.List;

import com.capgemini.appl.dto.Application;
import com.capgemini.appl.dto.ProgramsOffered;
import com.capgemini.appl.dto.ProgramsScheduled;
import com.capgemini.appl.dto.Users;
import com.capgemini.appl.exception.UniversityAdmissionException;

public interface UniversityService {

	List<Application> showApplications() throws UniversityAdmissionException;

	boolean addProgram(ProgramsOffered p) throws UniversityAdmissionException;
	
	List<ProgramsOffered> showProgramsOffereds()
			throws UniversityAdmissionException;

	boolean acceptOrRejectApplication(Application application) throws UniversityAdmissionException;
	boolean deleteProgram(String ProgramName)
			throws UniversityAdmissionException;

	boolean updateProgram(ProgramsOffered p)
			throws UniversityAdmissionException;
	
	Users getUserDetail(String userName)throws UniversityAdmissionException;
	String isUserAuthanticate(String userName,String password)throws UniversityAdmissionException;
	List<ProgramsScheduled> getAllProgramSheduled()throws UniversityAdmissionException;
	List<Application> getApplicationOnSheduledId(String ScheduleId)throws UniversityAdmissionException;
	boolean updateApplicationDB(int id,String status)throws UniversityAdmissionException;
	
	public List<Application> showApplicantInfo(String status,Date sqlStartDate,Date sqlEndDate) throws UniversityAdmissionException;


}
